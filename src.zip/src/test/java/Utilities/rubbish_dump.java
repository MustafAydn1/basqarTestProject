package Utilities;

public class rubbish_dump {
    public static void main(String[] args) {

  /*


  Scenario: Create Country and Cities and first delete city and after country
    When Go to countries Page
      | btnSetup1    |
      | btnParamtrs  |
      | btnCountries |


    And Create a Country
      |inputName|SOMECOUNTRY1|
      |inputCode|SC|

    And Save click
      |btnSave|

    When Go to cities and create a city
    Then Delete first city after country


    Then Check control successfully
   */











    }
}
